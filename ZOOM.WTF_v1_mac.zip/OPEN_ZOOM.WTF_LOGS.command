#!/bin/bash
open "$HOME/Library/Logs/ZOOM.WTF"
