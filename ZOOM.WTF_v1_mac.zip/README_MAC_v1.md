# ZOOM.WTF v1 for macOS

Double-click `ZOOM.WTF.app` once.

What it does:
- installs a login LaunchAgent automatically
- shows the party prompt on interactive launch
- launches only one Zoom instance
- does not open duplicates if Zoom is already running
- writes logs to `~/Library/Logs/ZOOM.WTF/`

Universal note:
- this is a shell-based `.app`, so it is architecture-neutral and works on Intel and Apple Silicon.

Files:
- `ZOOM.WTF.app` -> main app
- `REMOVE_ZOOM.WTF_AUTORUN.command` -> removes login autorun
- `OPEN_ZOOM.WTF_LOGS.command` -> opens the log folder

If Zoom is not in Applications, the app will try Spotlight lookup by bundle id `us.zoom.xos`.
