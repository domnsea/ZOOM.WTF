#!/bin/bash
set -u
set -o pipefail

APP_NAME="ZOOM.WTF"
SUPPORT_DIR="$HOME/Library/Application Support/ZOOM.WTF"
LOG_DIR="$HOME/Library/Logs/ZOOM.WTF"
PAYLOAD_LOG="$LOG_DIR/payload_$(date +%Y-%m-%d_%H%M%S).log"
mkdir -p "$SUPPORT_DIR" "$LOG_DIR"
exec >>"$PAYLOAD_LOG" 2>&1

echo "[START] payload $(date '+%Y-%m-%d %H:%M:%S')"

find_zoom_app() {
  local p
  for p in \
    "/Applications/zoom.us.app" \
    "$HOME/Applications/zoom.us.app" \
    "/Applications/Zoom.app" \
    "$HOME/Applications/Zoom.app"
  do
    if [ -d "$p" ]; then
      printf '%s\n' "$p"
      return 0
    fi
  done
  local found
  found="$(/usr/bin/mdfind "kMDItemCFBundleIdentifier == 'us.zoom.xos'" | head -n 1)"
  if [ -n "$found" ]; then
    printf '%s\n' "$found"
    return 0
  fi
  return 1
}

zoom_running() {
  /usr/bin/pgrep -ix "zoom.us" >/dev/null 2>&1 && return 0
  /usr/bin/pgrep -ix "Zoom" >/dev/null 2>&1 && return 0
  /usr/bin/pgrep -f "zoom.us.app" >/dev/null 2>&1 && return 0
  return 1
}

ZOOM_APP="$(find_zoom_app || true)"
if [ -z "$ZOOM_APP" ]; then
  echo "[ERROR] Zoom app not found"
  /usr/bin/osascript -e 'display dialog "ZOOM.WTF could not find Zoom on this Mac." buttons {"OK"} default button "OK" with icon caution' >/dev/null 2>&1 || true
  exit 1
fi

echo "[INFO] Zoom app: $ZOOM_APP"
if zoom_running; then
  echo "[INFO] Zoom is already running. Not opening another instance."
  exit 0
fi

echo "[ACTION] Opening Zoom once"
/usr/bin/open -a "$ZOOM_APP"
rc=$?
if [ "$rc" -ne 0 ]; then
  echo "[ERROR] open failed: $rc"
  exit "$rc"
fi
sleep 2
if zoom_running; then
  echo "[OK] Zoom started"
  exit 0
fi

echo "[WARN] open returned success but Zoom process not detected yet"
exit 0
