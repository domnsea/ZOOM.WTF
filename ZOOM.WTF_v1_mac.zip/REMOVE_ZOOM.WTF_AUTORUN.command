#!/bin/bash
set -u
PLIST="$HOME/Library/LaunchAgents/wtf.zoom.v1.plist"
/bin/launchctl bootout "gui/$(id -u)" "$PLIST" >/dev/null 2>&1 || /bin/launchctl unload "$PLIST" >/dev/null 2>&1 || true
rm -f "$PLIST"
/usr/bin/osascript -e 'display dialog "ZOOM.WTF autorun removed." buttons {"OK"} default button "OK"' >/dev/null 2>&1 || true
