# ZOOM.WTF for Windows

This package is the clean one-click Windows scaffold.

## Important
This is not a compiled native EXE produced in this environment.
It is the honest one-click package using a BAT launcher, Task Scheduler, and hidden VBS wrapper.

## User flow
1. Extract this zip to Desktop.
2. Keep `WINDOWS_1132FIX.ps1` in the same folder.
3. Double-click `ZOOM.WTF.bat`.

## Install autorun
Double-click `INSTALL_ZOOM.WTF_AUTORUN.bat`

## Remove autorun
Double-click `REMOVE_ZOOM.WTF_AUTORUN.bat`

## Debug visible run
Double-click `DEBUG_ZOOM.WTF_VISIBLE.bat`

## Logs
`C:\ProgramData\DomNSeaAutoRun\logs\`
