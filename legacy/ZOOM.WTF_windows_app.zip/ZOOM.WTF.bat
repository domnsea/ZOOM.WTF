@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "TASK_NAME=DomNSea_Windows1132_AutoRun"
set "STATE_DIR=%ProgramData%\DomNSeaAutoRun"
set "LOG_DIR=%STATE_DIR%\logs"
set "VBS_RUNNER=%STATE_DIR%\run_windows_1132fix_hidden.vbs"
set "TARGET_PATH=%~dp0WINDOWS_1132FIX.ps1"

if not exist "%STATE_DIR%" mkdir "%STATE_DIR%" >nul 2>&1
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>&1

for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HHmmss"') do set "STAMP=%%I"
if not defined STAMP set "STAMP=log"
set "LOG_FILE=%LOG_DIR%\windows_1132_autorun_%STAMP%.log"

echo [START] RUN_WINDOWS_1132FIX.bat > "%LOG_FILE%"
echo [INFO] ScriptDir=%~dp0 >> "%LOG_FILE%"
echo [INFO] Target=%TARGET_PATH% >> "%LOG_FILE%"
echo [INFO] Args=%* >> "%LOG_FILE%"

if /I "%~1"=="/install" goto :install
if /I "%~1"=="/uninstall" goto :uninstall
if /I "%~1"=="/run" goto :run
if /I "%~1"=="/visible" goto :visible

goto :launch_hidden_elevated

:check_target
if exist "%TARGET_PATH%" exit /b 0
echo [ERROR] Missing hard-wired target: %TARGET_PATH% >> "%LOG_FILE%"
powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Missing file: WINDOWS_1132FIX.ps1`n`nExpected beside:`n%~dp0','Dom N Sea AutoRun',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)" >nul 2>&1
exit /b 1

:ensure_admin_hidden
net session >nul 2>&1
if %errorlevel% equ 0 exit /b 0
echo [INFO] Requesting elevation... >> "%LOG_FILE%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:ComSpec -ArgumentList '/c ""%~f0"" /run' -Verb RunAs -WindowStyle Hidden" >> "%LOG_FILE%" 2>&1
set "ELEV_ERR=%errorlevel%"
if not "%ELEV_ERR%"=="0" (
  echo [ERROR] Elevation request failed code=%ELEV_ERR% >> "%LOG_FILE%"
  powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Could not get admin rights.`nLog:`n%LOG_FILE%','Dom N Sea AutoRun',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)" >nul 2>&1
  exit /b %ELEV_ERR%
)
exit /b 99

:write_vbs
echo [INFO] Writing hidden VBS runner to %VBS_RUNNER% >> "%LOG_FILE%"
> "%VBS_RUNNER%" echo Set WshShell = CreateObject^("WScript.Shell"^)
>> "%VBS_RUNNER%" echo cmd = """%~f0"" /run"
>> "%VBS_RUNNER%" echo WshShell.Run cmd, 0, False
exit /b 0

:install
call :check_target || exit /b 1
call :ensure_admin_hidden
if %errorlevel%==99 exit /b 0
if errorlevel 1 exit /b %errorlevel%
call :write_vbs || exit /b 1
echo [INFO] Installing scheduled task %TASK_NAME% >> "%LOG_FILE%"
schtasks /Create /TN "%TASK_NAME%" /SC ONLOGON /RL HIGHEST /TR "wscript.exe \"%VBS_RUNNER%\"" /F >> "%LOG_FILE%" 2>&1
set "INSTALL_ERR=%errorlevel%"
if not "%INSTALL_ERR%"=="0" (
  echo [ERROR] Scheduled task install failed code=%INSTALL_ERR% >> "%LOG_FILE%"
  powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Install failed.`nLog:`n%LOG_FILE%','Dom N Sea AutoRun',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)" >nul 2>&1
  exit /b %INSTALL_ERR%
)
powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Startup installed for WINDOWS_1132FIX.ps1','Dom N Sea AutoRun',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information)" >nul 2>&1
exit /b 0

:uninstall
call :ensure_admin_hidden
if %errorlevel%==99 exit /b 0
if errorlevel 1 exit /b %errorlevel%
echo [INFO] Removing scheduled task %TASK_NAME% >> "%LOG_FILE%"
schtasks /Delete /TN "%TASK_NAME%" /F >> "%LOG_FILE%" 2>&1
del /f /q "%VBS_RUNNER%" >nul 2>&1
powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Startup removed.','Dom N Sea AutoRun',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information)" >nul 2>&1
exit /b 0

:launch_hidden_elevated
call :check_target || exit /b 1
call :ensure_admin_hidden
if %errorlevel%==99 exit /b 0
if errorlevel 1 exit /b %errorlevel%
goto :run

:run
call :check_target || exit /b 1
net session >nul 2>&1
if %errorlevel% neq 0 exit /b 1
echo [INFO] Running hidden target... >> "%LOG_FILE%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; try { & '%TARGET_PATH%' *>> '%LOG_FILE%'; if ($null -eq $LASTEXITCODE) { exit 0 } else { exit [int]$LASTEXITCODE } } catch { $_ | Out-String | Add-Content -LiteralPath '%LOG_FILE%'; exit 1 }" >> "%LOG_FILE%" 2>&1
set "RUN_ERR=%errorlevel%"
echo [END] ExitCode=%RUN_ERR% >> "%LOG_FILE%"
if not "%RUN_ERR%"=="0" (
  powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('WINDOWS_1132FIX.ps1 failed.`nSee log:`n%LOG_FILE%','Dom N Sea AutoRun',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)" >nul 2>&1
  exit /b %RUN_ERR%
)
exit /b 0

:visible
call :check_target || exit /b 1
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:ComSpec -ArgumentList '/k ""%~f0"" /visible' -Verb RunAs"
  exit /b 0
)
echo [INFO] Visible run for debugging. Log: "%LOG_FILE%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%TARGET_PATH%"
set "RUN_ERR=%errorlevel%"
echo [END] ExitCode=%RUN_ERR% >> "%LOG_FILE%"
exit /b %RUN_ERR%
