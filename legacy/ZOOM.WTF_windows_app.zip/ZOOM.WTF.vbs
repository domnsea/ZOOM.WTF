Set WshShell = CreateObject("WScript.Shell")
cmd = Chr(34) & CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName) & "\ZOOM.WTF.bat" & Chr(34)
WshShell.Run cmd, 0, False
