#Requires -RunAsAdministrator
# 1132 workaround — max 3 rotating temporary local accounts (storage-friendly).
# UTF-8 (Slag display names).
# Removes only the one slot account dictated by the rotation — never the admin runner, never bulk cleanup.
# Launches Zoom twice as the active user: after the first start, ends the idle Zoom task (0% CPU) like
# Task Manager, then starts the second Zoom with a separate --data profile (--multipt) so Windows does
# not merge both into a single instance.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$PlainPassword = 'ZoomTemp123!'
$SecurePassword = ConvertTo-SecureString $PlainPassword -AsPlainText -Force

$AccountNames = @('z1132slg1', 'z1132slg2', 'z1132slg3')
$DisplayNames = @(
    ('Zoom Slag ' + [char]::ConvertFromUtf32(0x1F3B1)),
    ('Slag ' + [char]::ConvertFromUtf32(0x1F3B1)),
    'Slag.wtf'
)

$StateDir  = Join-Path $env:ProgramData 'Zoom1132'
$StateFile = Join-Path $StateDir 'slag_next_slot.txt'

function Get-ZoomExePath {
    $candidates = @(
        'C:\Users\BALLROOM\AppData\Zoom\bin\Zoom.exe'
        (Join-Path $env:ProgramFiles 'Zoom\bin\Zoom.exe')
        (Join-Path $env:LOCALAPPDATA 'Programs\Zoom\bin\Zoom.exe')
        (Join-Path $env:LOCALAPPDATA 'Zoom\bin\Zoom.exe')
    )
    foreach ($p in $candidates) {
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

function Remove-AccountAndProfile {
    param([Parameter(Mandatory)][string]$UserName)

    if (-not $UserName) { return }
    $user = Get-LocalUser -Name $UserName -ErrorAction SilentlyContinue
    if ($user) {
        try { Remove-LocalUser -Name $UserName -ErrorAction Stop }
        catch {
            Write-Warning "Remove-LocalUser failed for $UserName : $_"
        }
    }
    $profilePath = Join-Path $env:SystemDrive "Users\$UserName"
    if (Test-Path -LiteralPath $profilePath) {
        try {
            Remove-Item -LiteralPath $profilePath -Recurse -Force -ErrorAction Stop
        }
        catch {
            Write-Warning "Could not remove profile folder $profilePath : $_"
        }
    }
}

function Ensure-LocalAccount {
    param(
        [Parameter(Mandatory)][string]$UserName,
        [Parameter(Mandatory)][string]$FullName
    )
    $exists = Get-LocalUser -Name $UserName -ErrorAction SilentlyContinue
    if (-not $exists) {
        New-LocalUser -Name $UserName -Password $SecurePassword -FullName $FullName `
            -Description 'Temporary Zoom Account (1132 rotation)' | Out-Null
        Add-LocalGroupMember -Group 'Administrators' -Member $UserName -ErrorAction Stop
    }
    else {
        $exists | Set-LocalUser -FullName $FullName -ErrorAction SilentlyContinue
    }
}

function Stop-ZoomIdleHelperLikeTaskManager {
    <#
      Task Manager shows 2 Zoom lines: KEEP the first Start-Process (your meeting). END TASK only the *other*
      Zoom.exe (the 0.0% line). Never kill FirstLaunchPid — CPU/WMI was wrongly picking the main window before.
    #>
    param([Parameter(Mandatory)][int]$FirstLaunchPid)

    $first = Get-Process -Id $FirstLaunchPid -ErrorAction SilentlyContinue
    $sessionId = if ($first) { $first.SessionId } else { $null }

    $spin = 0
    while ($spin -lt 70) {
        $all = @(Get-Process -Name Zoom -ErrorAction SilentlyContinue)
        if ($null -ne $sessionId) {
            $all = @($all | Where-Object { $_.SessionId -eq $sessionId })
        }
        if ($all.Count -ge 2) { break }
        Start-Sleep -Milliseconds 400
        $spin++
    }

    $candidates = @(Get-Process -Name Zoom -ErrorAction SilentlyContinue)
    if ($null -ne $sessionId) {
        $same = @($candidates | Where-Object { $_.SessionId -eq $sessionId })
        if ($same.Count -ge 2) { $candidates = $same }
    }

    if ($candidates.Count -lt 2) {
        Write-Host '[ACTION] Fewer than 2 Zoom.exe in this session - helper not ready yet.'
        return $false
    }

    if ($candidates.Id -notcontains $FirstLaunchPid) {
        Write-Host '[ACTION] First Start-Process PID is no longer a running Zoom - skip end-task (unsafe).'
        return $false
    }

    $keepId = $FirstLaunchPid
    $others = @($candidates | Where-Object { $_.Id -ne $keepId })
    if ($others.Count -lt 1) {
        Write-Host '[ACTION] Could not find a Zoom PID other than first launch - skip end-task.'
        return $false
    }

    $victimId = $null
    if ($candidates.Count -eq 2) {
        $victimId = $others[0].Id
        Write-Host ('[ACTION] Keep first Zoom PID {0} (meeting). End task on the other PID {1} (0.0 percent line).' -f $keepId, $victimId)
    }
    else {
        $live = @(Get-Process -Name Zoom -ErrorAction SilentlyContinue | Where-Object { $others.Id -contains $_.Id })
        $noWin = @($live | Where-Object { [int64]$_.MainWindowHandle -eq 0 })
        if ($noWin.Count -ge 1) {
            $victimId = ($noWin | Sort-Object Id -Descending | Select-Object -First 1).Id
            Write-Host ('[ACTION] Keep PID {0}. End no-window helper PID {1}.' -f $keepId, $victimId)
        }
        else {
            $victimId = ($others | Sort-Object Id | Select-Object -First 1).Id
            Write-Host ('[ACTION] Keep PID {0}. End auxiliary Zoom PID {1}.' -f $keepId, $victimId)
        }
    }

    if ($victimId -eq $keepId) {
        Write-Host '[ACTION] Safety: refuse to end first-launch Zoom.'
        return $false
    }

    try {
        Stop-Process -Id $victimId -Force -ErrorAction Stop
        Write-Host ('[ACTION] Ended PID {0}. Relaunching Zoom for second instance.' -f $victimId)
        return $true
    }
    catch {
        Write-Warning $_.Exception.Message
        return $false
    }
}

function Get-SlotToRemoveBeforeLaunch {
    param([int]$SlotAboutToRun)
    # Exactly ONE of the three accounts is removed per run (never more than one).
    # When (3) loads → completely wipe (1). When (1) loads → delete (2). When (2) loads → delete (3).
    switch ($SlotAboutToRun) {
        1 { return 2 }
        2 { return 3 }
        3 { return 1 }
        default { throw "Invalid slot $SlotAboutToRun" }
    }
}

Write-Host '[START] Temporary Zoom launcher (3-slot rotation)...'

$zoom = Get-ZoomExePath
if (-not $zoom) {
    Write-Host '[ERROR] Zoom.exe not found. Checked BALLROOM path, Program Files, and LocalAppData.'
    exit 1
}

Write-Host ('[OK] Using Zoom path: {0}' -f $zoom)

# Start-Process -Credential fails with "The directory name is invalid" if WorkingDirectory is the
# admin's path (e.g. another user's profile). Use Zoom's install folder instead.
$zoomWorkDir = [System.IO.Path]::GetDirectoryName($zoom)
if (-not (Test-Path -LiteralPath $zoomWorkDir)) {
    $zoomWorkDir = $env:SystemRoot
}

$ZoomArgs1 = @('--multipt=TRUE', '--data=data1132slgA')
$ZoomArgs2 = @('--multipt=TRUE', '--data=data1132slgB')

if (-not (Test-Path -LiteralPath $StateDir)) {
    New-Item -ItemType Directory -Path $StateDir -Force | Out-Null
}

$next = 1
if (Test-Path -LiteralPath $StateFile) {
    $raw = (Get-Content -LiteralPath $StateFile -Raw -ErrorAction SilentlyContinue).Trim()
    if ($raw -match '^[123]$') { [int]$next = [int]$raw }
}

$removeSlot = Get-SlotToRemoveBeforeLaunch -SlotAboutToRun $next
$removeName = $AccountNames[$removeSlot - 1]
$activeName = $AccountNames[$next - 1]
$activeFull = $DisplayNames[$next - 1]

Write-Host ('[ROTATE] Launching slot {0} ({1}); removing exactly one other slot: {2} ({3})...' -f $next, $activeFull, $removeSlot, $removeName)
Remove-AccountAndProfile -UserName $removeName

Ensure-LocalAccount -UserName $activeName -FullName $activeFull

$cred = New-Object System.Management.Automation.PSCredential(
    $activeName,
    $SecurePassword
)
Write-Host ('[ACTION] Zoom instance 1 - {0} ({1})' -f $activeName, $activeFull)
$p1 = Start-Process -FilePath $zoom -ArgumentList $ZoomArgs1 -WorkingDirectory $zoomWorkDir -Credential $cred -PassThru -WindowStyle Normal
if (-not $p1) {
    Write-Host '[ERROR] First Zoom Start-Process did not return a process.'
    exit 1
}
Start-Sleep -Seconds 4
if (-not (Stop-ZoomIdleHelperLikeTaskManager -FirstLaunchPid $p1.Id)) {
    Write-Host ('[ACTION] Could not end idle Zoom helper - starting 2nd Zoom anyway (may still be one window).')
}
Start-Sleep -Milliseconds 600
Write-Host ('[ACTION] Zoom instance 2 - {0} (after idle process end)' -f $activeName)
$p2 = Start-Process -FilePath $zoom -ArgumentList $ZoomArgs2 -WorkingDirectory $zoomWorkDir -Credential $cred -PassThru -WindowStyle Normal
foreach ($id in @($p1.Id, $p2.Id)) {
    if (Get-Process -Id $id -ErrorAction SilentlyContinue) {
        Wait-Process -Id $id -ErrorAction SilentlyContinue
    }
}

$following = if ($next -ge 3) { 1 } else { $next + 1 }
Set-Content -LiteralPath $StateFile -Value $following -Encoding ascii -Force
Write-Host ('[STATE] Next run will use slot {0}.' -f $following)

Write-Host ''
Write-Host 'DONE: One slot account was rotated off; second Zoom started after ending idle zero-percent Zoom (Task Manager pattern).'
