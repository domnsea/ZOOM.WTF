#!/bin/bash
set -euo pipefail
PLIST="$HOME/Library/LaunchAgents/com.zoomwtf.autorun.plist"
launchctl bootout "gui/$(id -u)" "$PLIST" >/dev/null 2>&1 || true
rm -f "$PLIST"
osascript -e 'display dialog "ZOOM.WTF autorun removed." buttons {"OK"} default button "OK" with icon note' >/dev/null 2>&1 || true
