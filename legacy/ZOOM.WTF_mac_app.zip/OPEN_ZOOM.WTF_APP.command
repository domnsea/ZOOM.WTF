#!/bin/bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)/ZOOM.WTF.app"
open "$APP_DIR"
