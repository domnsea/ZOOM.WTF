Set WshShell = CreateObject("WScript.Shell")
folder = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
bat = folder & "\ZOOM.WTF.bat"
WshShell.Run Chr(34) & bat & Chr(34), 0, False
