## ZOOM.WTF v1

This is the cleaned Windows package.

### What changed

| Change | Result |
|---|---|
| single Zoom launch only | no second Zoom instance |
| cleaned package | no nested old folders |
| startup installer | scheduled task at logon with highest rights |
| shortcut creator | creates a Desktop shortcut named `ZOOM.WTF` |

### Use these files

| File | What it does |
|---|---|
| `INSTALL_ZOOM.WTF_AUTORUN.bat` | installs autorun |
| `ZOOM.WTF.vbs` | quiet launcher |
| `DEBUG_ZOOM.WTF_VISIBLE.bat` | visible debug run |
| `OPEN_ZOOM.WTF_LOGS.bat` | opens engine logs |
| `REMOVE_ZOOM.WTF_AUTORUN.bat` | removes autorun |

### Logs

Engine logs:

`C:\ProgramData\Zoom1132\logs`

Launcher logs:

`C:\ProgramData\ZOOM.WTF\logs`
