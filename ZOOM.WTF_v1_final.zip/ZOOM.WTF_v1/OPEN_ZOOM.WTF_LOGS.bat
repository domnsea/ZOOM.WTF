@echo off
start "" "C:\ProgramData\Zoom1132\logs"
