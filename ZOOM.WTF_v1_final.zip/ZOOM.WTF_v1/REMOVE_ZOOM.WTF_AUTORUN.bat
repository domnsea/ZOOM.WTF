@echo off
cd /d "%~dp0"
call "%~dp0ZOOM.WTF.bat" /uninstall
