Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:AppName    = 'ZOOM.WTF v1'
$script:StateDir   = Join-Path $env:ProgramData 'Zoom1132'
$script:LogDir     = Join-Path $script:StateDir 'logs'
$script:ProfilesDir= Join-Path $script:StateDir 'profiles'
$script:StateFile  = Join-Path $script:StateDir 'slag_next_slot.txt'
$script:LogFile    = Join-Path $script:LogDir ("engine_{0}.log" -f (Get-Date -Format 'yyyy-MM-dd_HHmmss'))

function Write-Step {
    param([string]$Level, [string]$Message)
    $line = "[{0}] {1}" -f $Level.ToUpperInvariant(), $Message
    Write-Host $line
}

function Test-IsAdmin {
    $currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($currentIdentity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Ensure-Elevated {
    if (Test-IsAdmin) { return }
    $self = $PSCommandPath
    if (-not $self) { throw 'Could not determine script path for elevation.' }
    Write-Step INFO 'Not elevated. Relaunching with Administrator rights...'
    $args = @(
        '-NoProfile'
        '-ExecutionPolicy', 'Bypass'
        '-File', ('"{0}"' -f $self)
    )
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList ($args -join ' ')
    exit 0
}

function Ensure-Dirs {
    foreach ($dir in @($script:StateDir, $script:LogDir, $script:ProfilesDir)) {
        if (-not (Test-Path -LiteralPath $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
    }
}

function Start-Logging {
    Ensure-Dirs
    Start-Transcript -Path $script:LogFile -Append | Out-Null
    Write-Step START $script:AppName
    Write-Step INFO ("User={0} Computer={1}" -f $env:USERNAME, $env:COMPUTERNAME)
    Write-Step INFO ("PSCommandPath={0}" -f $PSCommandPath)
}

function Stop-Logging {
    try { Stop-Transcript | Out-Null } catch {}
}

function Get-ZoomExePath {
    $candidates = [System.Collections.Generic.List[string]]::new()

    foreach ($key in @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\Zoom.exe',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\Zoom.exe'
    )) {
        try {
            $regValue = (Get-ItemProperty -Path $key -ErrorAction Stop).'(default)'
            if ($regValue) { [void]$candidates.Add($regValue) }
        }
        catch {}
    }

    foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ($base) {
            [void]$candidates.Add((Join-Path $base 'Zoom\bin\Zoom.exe'))
        }
    }

    foreach ($userDir in (Get-ChildItem 'C:\Users' -Directory -Force -ErrorAction SilentlyContinue)) {
        foreach ($relative in @(
            'AppData\Roaming\Zoom\bin\Zoom.exe',
            'AppData\Local\Programs\Zoom\bin\Zoom.exe',
            'AppData\Zoom\bin\Zoom.exe'
        )) {
            [void]$candidates.Add((Join-Path $userDir.FullName $relative))
        }
    }

    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) {
            return $candidate
        }
    }

    return $null
}

function Remove-AccountAndProfile {
    param([Parameter(Mandatory)][string]$UserName)

    if (-not $UserName) { return }

    Write-Step INFO ("Removing old slot account/profile if present: {0}" -f $UserName)

    $user = Get-LocalUser -Name $UserName -ErrorAction SilentlyContinue
    if ($user) {
        try {
            Remove-LocalUser -Name $UserName -ErrorAction Stop
            Write-Step OK ("Removed local user {0}" -f $UserName)
        }
        catch {
            Write-Step WARN ("Remove-LocalUser failed for {0}: {1}" -f $UserName, $_.Exception.Message)
        }
    }

    $profilePath = Join-Path $env:SystemDrive ("Users\{0}" -f $UserName)
    try {
        $escaped = $profilePath.Replace('\\', '\\\\')
        $profile = Get-CimInstance Win32_UserProfile -Filter ("LocalPath='{0}'" -f $escaped) -ErrorAction SilentlyContinue
        if ($profile) {
            $profile | Remove-CimInstance -ErrorAction Stop
            Write-Step OK ("Removed Windows profile object {0}" -f $profilePath)
        }
        elseif (Test-Path -LiteralPath $profilePath) {
            Remove-Item -LiteralPath $profilePath -Recurse -Force -ErrorAction Stop
            Write-Step OK ("Removed profile folder {0}" -f $profilePath)
        }
    }
    catch {
        Write-Step WARN ("Profile cleanup failed for {0}: {1}" -f $UserName, $_.Exception.Message)
    }
}

function Ensure-LocalAccount {
    param(
        [Parameter(Mandatory)][string]$UserName,
        [Parameter(Mandatory)][string]$FullName,
        [Parameter(Mandatory)][securestring]$Password
    )

    $existing = Get-LocalUser -Name $UserName -ErrorAction SilentlyContinue
    if (-not $existing) {
        New-LocalUser -Name $UserName -Password $Password -FullName $FullName -Description 'Temporary Zoom Account (1132 rotation)' -PasswordNeverExpires -AccountNeverExpires | Out-Null
        Write-Step OK ("Created local user {0}" -f $UserName)
    }
    else {
        $existing | Set-LocalUser -FullName $FullName -Password $Password -Description 'Temporary Zoom Account (1132 rotation)' | Out-Null
        Write-Step OK ("Updated local user {0}" -f $UserName)
    }

    try {
        Add-LocalGroupMember -Group 'Administrators' -Member $UserName -ErrorAction Stop
        Write-Step OK ("Added {0} to Administrators" -f $UserName)
    }
    catch {
        if ($_.Exception.Message -match 'already a member') {
            Write-Step INFO ("{0} is already in Administrators" -f $UserName)
        }
        else {
            throw
        }
    }
}

function Ensure-PathAclForUser {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$UserName
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }

    $qualifiedUser = "{0}\{1}" -f $env:COMPUTERNAME, $UserName
    $grantUser = ("{0}:(OI)(CI)M" -f $qualifiedUser)
    & icacls $Path /inheritance:e /grant:r $grantUser 'Administrators:(OI)(CI)F' | Out-Null
    Write-Step INFO ("Granted write access to {0}: {1}" -f $qualifiedUser, $Path)
}

function Get-SlotToRemoveBeforeLaunch {
    param([int]$SlotAboutToRun)
    switch ($SlotAboutToRun) {
        1 { return 2 }
        2 { return 3 }
        3 { return 1 }
        default { throw "Invalid slot $SlotAboutToRun" }
    }
}

$PlainPassword = 'ZoomTemp123!'
$SecurePassword = ConvertTo-SecureString $PlainPassword -AsPlainText -Force
$AccountNames = @('z1132slg1', 'z1132slg2', 'z1132slg3')
$DisplayNames = @('Zoom Slag 1', 'Zoom Slag 2', 'Slag.wtf')

try {
    Ensure-Elevated
    Start-Logging

    $zoom = Get-ZoomExePath
    if (-not $zoom) {
        throw 'Zoom.exe was not found in registry, Program Files, or any user AppData path.'
    }
    Write-Step OK ("Using Zoom path: {0}" -f $zoom)

    $zoomWorkDir = [System.IO.Path]::GetDirectoryName($zoom)
    if (-not $zoomWorkDir -or -not (Test-Path -LiteralPath $zoomWorkDir)) {
        $zoomWorkDir = $env:SystemRoot
    }
    Write-Step INFO ("WorkingDirectory={0}" -f $zoomWorkDir)

    if (-not (Test-Path -LiteralPath $script:StateFile)) {
        Set-Content -LiteralPath $script:StateFile -Value '1' -Encoding ascii -Force
        Write-Step INFO 'Created rotation state file with slot 1.'
    }

    [int]$next = 1
    $raw = (Get-Content -LiteralPath $script:StateFile -Raw -ErrorAction SilentlyContinue).Trim()
    if ($raw -match '^[123]$') {
        $next = [int]$raw
    }
    else {
        Write-Step WARN ("State file was invalid: '{0}'. Resetting to slot 1." -f $raw)
        $next = 1
    }

    $removeSlot = Get-SlotToRemoveBeforeLaunch -SlotAboutToRun $next
    $removeName = $AccountNames[$removeSlot - 1]
    $activeName = $AccountNames[$next - 1]
    $activeFull = $DisplayNames[$next - 1]

    Write-Step INFO ("Rotation: launch slot {0} ({1}), remove slot {2} ({3})" -f $next, $activeName, $removeSlot, $removeName)

    Remove-AccountAndProfile -UserName $removeName
    Ensure-LocalAccount -UserName $activeName -FullName $activeFull -Password $SecurePassword

    $profileRoot = Join-Path $script:ProfilesDir $activeName
    $profileData = Join-Path $profileRoot 'data'
    Ensure-PathAclForUser -Path $profileRoot -UserName $activeName
    Ensure-PathAclForUser -Path $profileData -UserName $activeName

    $zoomArgs = @("--data=$profileData")

    $qualifiedUser = "{0}\{1}" -f $env:COMPUTERNAME, $activeName
    $cred = [pscredential]::new($qualifiedUser, $SecurePassword)

    Write-Step ACTION ("Starting single Zoom instance as {0}" -f $qualifiedUser)
    $zoomProc = Start-Process -FilePath $zoom -ArgumentList $zoomArgs -WorkingDirectory $zoomWorkDir -Credential $cred -PassThru -WindowStyle Normal
    if (-not $zoomProc) {
        throw 'Zoom Start-Process did not return a process object.'
    }
    Write-Step OK ("Zoom PID={0}" -f $zoomProc.Id)

    if (Get-Process -Id $zoomProc.Id -ErrorAction SilentlyContinue) {
        Wait-Process -Id $zoomProc.Id -ErrorAction SilentlyContinue
    }

    $following = if ($next -ge 3) { 1 } else { $next + 1 }
    Set-Content -LiteralPath $script:StateFile -Value $following -Encoding ascii -Force
    Write-Step STATE ("Next run will use slot {0}" -f $following)
    Write-Step DONE 'Completed.'
}
catch {
    Write-Step FATAL $_.Exception.Message
    Write-Step FATAL ("See log: {0}" -f $script:LogFile)
    exit 1
}
finally {
    Stop-Logging
}
