@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ICON=%~dp0ZOOM.WTF_icon.ico"
set "TARGET=%~dp0ZOOM.WTF.vbs"
set "SHORTCUT=%USERPROFILE%\Desktop\ZOOM.WTF.lnk"

if not exist "%TARGET%" exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut($env:SHORTCUT); $s.TargetPath=$env:TARGET; $s.WorkingDirectory=Split-Path $env:TARGET; if (Test-Path $env:ICON) { $s.IconLocation=$env:ICON }; $s.Save()" >nul 2>&1
exit /b 0
