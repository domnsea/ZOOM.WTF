@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "APP_NAME=ZOOM.WTF v1"
set "TASK_NAME=ZOOM.WTF_v1_AutoRun"
set "TARGET_PS1=%~dp0WINDOWS_1132FIX_FIXED.ps1"
set "APP_DIR=%ProgramData%\ZOOM.WTF"
set "LOG_DIR=%APP_DIR%\logs"
set "WRAP_LOG=%LOG_DIR%\launcher.log"

if not exist "%APP_DIR%" mkdir "%APP_DIR%" >nul 2>&1
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>&1

echo [%date% %time%] START %~nx0 %*>> "%WRAP_LOG%"

goto :dispatch

:dispatch
if /I "%~1"=="/install" goto :install
if /I "%~1"=="/uninstall" goto :uninstall
if /I "%~1"=="/run" goto :run
if /I "%~1"=="/visible" goto :visible
if /I "%~1"=="/logfolder" goto :logfolder
goto :launch_hidden

:logfolder
start "" "C:\ProgramData\Zoom1132\logs"
exit /b 0

:check_target
if exist "%TARGET_PS1%" exit /b 0
call :show_error "Missing WINDOWS_1132FIX_FIXED.ps1 beside the app package." "Expected in the same folder as ZOOM.WTF.bat."
exit /b 1

:is_admin
net session >nul 2>&1
if %errorlevel% equ 0 (
  exit /b 0
) else (
  exit /b 1
)

:ensure_admin
call :is_admin
if %errorlevel% equ 0 exit /b 0
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:ComSpec -ArgumentList '/c ""%~f0"" %~1' -Verb RunAs"
set "ELEV_ERR=%errorlevel%"
if not "%ELEV_ERR%"=="0" (
  echo [%date% %time%] Elevation failed code=%ELEV_ERR%>> "%WRAP_LOG%"
  call :show_error "Could not get administrator rights." "UAC was cancelled or blocked."
  exit /b %ELEV_ERR%
)
exit /b 99

:show_error
set "M1=%~1"
set "M2=%~2"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$msg = @'
%M1%

%M2%
'@; Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show($msg,'%APP_NAME%',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null" >nul 2>&1
exit /b 1

:show_info
set "M1=%~1"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$msg = @'
%M1%
'@; Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show($msg,'%APP_NAME%',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null" >nul 2>&1
exit /b 0

:install
call :check_target || exit /b 1
call :ensure_admin /install
if %errorlevel%==99 exit /b 0
if errorlevel 1 exit /b %errorlevel%

echo [%date% %time%] Installing scheduled task %TASK_NAME%>> "%WRAP_LOG%"
schtasks /Create /TN "%TASK_NAME%" /SC ONLOGON /RL HIGHEST /TR "powershell.exe -WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File \"%TARGET_PS1%\"" /F >> "%WRAP_LOG%" 2>&1
if errorlevel 1 (
  call :show_error "Install failed." "Open %LOG_DIR% for launcher.log."
  exit /b 1
)
call "%~dp0CREATE_ZOOM.WTF_SHORTCUT.bat" >nul 2>&1
call :show_info "Startup installed. This v1 build launches one Zoom instance only."
exit /b 0

:uninstall
call :ensure_admin /uninstall
if %errorlevel%==99 exit /b 0
if errorlevel 1 exit /b %errorlevel%

echo [%date% %time%] Removing scheduled task %TASK_NAME%>> "%WRAP_LOG%"
schtasks /Delete /TN "%TASK_NAME%" /F >> "%WRAP_LOG%" 2>&1
call :show_info "Startup removed."
exit /b 0

:launch_hidden
call :ensure_admin /run
if %errorlevel%==99 exit /b 0
if errorlevel 1 exit /b %errorlevel%
goto :run

:run
call :check_target || exit /b 1
call :is_admin
if %errorlevel% neq 0 exit /b 1
powershell -WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File "%TARGET_PS1%"
set "RUN_ERR=%errorlevel%"
echo [%date% %time%] Run exit code=%RUN_ERR%>> "%WRAP_LOG%"
if not "%RUN_ERR%"=="0" (
  call :show_error "WINDOWS_1132FIX_FIXED.ps1 failed." "Open C:\ProgramData\Zoom1132\logs or use DEBUG_ZOOM.WTF_VISIBLE.bat."
  exit /b %RUN_ERR%
)
exit /b 0

:visible
call :check_target || exit /b 1
call :ensure_admin /visible
if %errorlevel%==99 exit /b 0
if errorlevel 1 exit /b %errorlevel%
cls
echo ======================================================
echo ZOOM.WTF v1 DEBUG MODE
echo Single-instance Zoom launch
echo ======================================================
echo.
echo Target: "%TARGET_PS1%"
echo Logs  : C:\ProgramData\Zoom1132\logs
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%TARGET_PS1%"
set "RUN_ERR=%errorlevel%"
echo.
echo Exit code: %RUN_ERR%
echo.
echo Press any key to open the log folder.
pause >nul
start "" "C:\ProgramData\Zoom1132\logs"
exit /b %RUN_ERR%
